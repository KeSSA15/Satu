package Main;

import login.MVCLogin;
    public class Main {
    public static void main(String[] args) {
        new MVCLogin();
    }
    
}
